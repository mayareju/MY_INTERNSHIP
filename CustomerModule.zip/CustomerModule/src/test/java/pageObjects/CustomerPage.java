package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CustomerPage {

	
	public WebDriver driver;
	
	public CustomerPage(WebDriver driver) {
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//a[@href='https://phptravels.net/account/bookings']/i")
	private WebElement booking;
	
	@FindBy(xpath="(//a[text()=' View Voucher'])[1]")
	private WebElement voucher;
	
	@FindBy(xpath="//button[@id='download']")
	private WebElement voucherdownload;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/add_funds']/i")
	private WebElement addfunds;
	
	@FindBy(xpath="//input[@id='gateway_paypal']")
	private WebElement radiobutton;	
	
	@FindBy(xpath="//button[@type='submit']/i")
	private WebElement paynow;	
	
	@FindBy(xpath="//div[@class='btn-front']")
	private WebElement backtoinvoice;	
	
	@FindBy(xpath="//a[text()='Yes']")
	private WebElement alert;	
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/profile']/i")
	private WebElement profile;
	
	@FindBy(xpath="//input[@name='address1']")
	private WebElement address;
	
	@FindBy(xpath="//button[text()='Update Profile']")
	private WebElement update;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/logout']/i")
	private WebElement logout;
	
	public void clickMyBooking() {
		booking.click();
	}
	
	public void clickVoucher() {
		voucher.click();
	}
	
	public void clickAddFunds() {
		addfunds.click();
	}

	public void clickPaywithPaypal() {
		radiobutton.click();
	}

	public void clickPayNow() {
		paynow.click();
	}

	public void clickBacktoInvoice() {
		backtoinvoice.click();
	}

	public void clickAlertYes() {
		alert.click();
	}
	
	public void clickMyProfile() {
		profile.click();
	}
	
	public void strAddress(String strAddress) {
		address.clear();
		address.sendKeys(strAddress);
	}
	
	public void clickUpdate() {
		update.click();
	}
	
//	public boolean downloadInvoice() {
//		boolean invoice = voucherdownload.isEnabled();
//		return invoice;
//	}
	
	public boolean buttoninvoice() {
		boolean button = voucher.isEnabled();
		return button;
	}
	
	public String Window() {
		String parent = driver.getWindowHandle();
		return parent;
	}
	public void clickLogout() {
		logout.click();
	}
	
}
