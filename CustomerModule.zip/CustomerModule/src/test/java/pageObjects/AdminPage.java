package pageObjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminPage {

	
	
public WebDriver driver;
	
	public AdminPage(WebDriver driver) {
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="(//a[@href='https://phptravels.net/api/admin/bookings'])[1]")
	private WebElement bookings;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/api/../hotels/booking/invoice/8132/9']")
	private WebElement invoice;
	
	@FindBy(xpath="//div[@class='infobox infobox-success']")
	private WebElement checkstatus;
	
	@FindBy(xpath="(//button[@class=\"btn btn-danger mdc-ripple-upgraded\"])[2]")
	private WebElement deleteinvoice;	
	
	@FindBy(xpath="//div[text()='Pending Bookings']")
	private WebElement pending;
	
	@FindBy(xpath="(//select[@class='form-select status pending'])[1]")
	private WebElement selectpending;	
	
	@FindBy(xpath="(//option[text()='Confirmed'])[1]")
	private WebElement selectconform;
	
	@FindBy(xpath="(//div[@class=\"display-5\"])[2]")
	private WebElement pendingnum;
	
	@FindBy(xpath="(//div[@class=\"display-5\"])[1]")
	private WebElement confirmnum;
	
	@FindBy(xpath="//a[text()='Website']")
	private WebElement website;
	
//	@FindBy(xpath="//strong[text()=' Confirmed ']")
//	private WebElement checkstatus;
	
	public void clickAdminBooking() {
		bookings.click();
	}
	
	public void clickAdminInvoice() {
		invoice.click();
	}
	
	public boolean getStatus() {
		boolean status = checkstatus.getText().contains("paid");
		return status;
	}
	
	public void deleteAdminInvoice() throws Exception {
		JavascriptExecutor ex = (JavascriptExecutor)driver;
		ex.executeScript("window.scrollBy(100,0)");
		deleteinvoice.click();
		Thread.sleep(3000);
		driver.switchTo().alert().dismiss();
	}
	
	public void clickPending() {
		pending.click();
	}
	public void selectPending() {
		selectpending.click();
	}
	public void selectConform() {
		selectconform.click();
	}
	
	public String numPending() {
		String num = pendingnum.getText();
		//int newcount=Integer.parseInt(num);
		return num;
	}
	
	public String numConfirm() {
		String num = confirmnum.getText();
		return num;
	}
	
	public void selectWbsite() {
		website.click();
	}
//	//Open a new tab using Ctrl + t
//	@FindBy(css="body")
//	private WebElement newtab;
//	
//	public void newTab() {
//		newtab.sendKeys(Keys.CONTROL +"t");
//		newtab.sendKeys(Keys.CONTROL +"\t");
//	}
	
}
