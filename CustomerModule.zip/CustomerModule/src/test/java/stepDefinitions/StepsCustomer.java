package stepDefinitions;

import java.util.ArrayList;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.AdminPage;
import pageObjects.AgentPage;
import pageObjects.CustomerPage;
import pageObjects.LoginPage;

public class StepsCustomer {
	
	public WebDriver driver;
	public LoginPage login;
	public CustomerPage customer;
	public AgentPage agent;
	public AdminPage admin;

	
	@Given("User Launch Chrome browser")
	public void user_launch_chrome_browser() {
	    driver=new EdgeDriver();
	    login=new LoginPage(driver);
	    customer=new CustomerPage(driver);
	    agent=new AgentPage(driver);
	    admin=new AdminPage(driver);
	}

	@When("user open url {string}")
	public void user_open_url(String url) throws InterruptedException {
	    driver.get(url);
	    Thread.sleep(3000);
	    driver.manage().window().maximize();
	}

	@When("User enters Email as {string} and password as {string}")
	public void user_enters_email_as_and_password_as(String Email, String Password) throws InterruptedException {
		Thread.sleep(3000);
		login.userEmail(Email);
		Thread.sleep(3000);
		login.userPassword(Password);
	}

	@When("click Login button")
	public void click_login_button() throws InterruptedException {
		Thread.sleep(3000);
		login.clickLogin();
		Thread.sleep(3000);
	}
	//Login
	@When("users enters Email as {string} and password as {string}")
	public void users_enters_email_as_and_password_as(String email, String pass) throws Exception {
		Thread.sleep(3000);
		login.userEmail(email);
		Thread.sleep(3000);
		login.userPassword(pass);
	}

//	@When("user click login")
//	public void user_click_login() {
//	    // Write code here that turns the phrase above into concrete actions
//	    throw new io.cucumber.java.PendingException();
//	}

	@Then("user Page url should contain {string}")
	public void user_page_url_should_contain(String title) throws InterruptedException {
		Thread.sleep(3000);
		if(driver.getCurrentUrl().contains(title)){
			driver.close();
	    	Assert.assertTrue(true);
		}
	    	else if(driver.getCurrentUrl().contains("failed")){
			driver.close();
	    	Assert.assertTrue(true);
		}
		else if(login.getErrorEmailMsg().contains("Please fill out")) {
			driver.close();
			Assert.assertTrue(true);}
		else if(login.getErrorPassMsg().contains("Please fill out")) {
			driver.close();
			Assert.assertTrue(true);}
	}


	@When("admin open url {string}")
	public void admin_open_url(String url) throws InterruptedException {
		driver.get(url);
	    Thread.sleep(3000);
	    driver.manage().window().maximize();
	}

//	@When("admin click login")
//	public void admin_click_login() {
//	    
//	}

	@Then("admin Page title should contain {string}")
	public void admin_page_title_should_contain(String title) {
		if(driver.getTitle().contains(title)) {
			driver.close();
			Assert.assertTrue(true);
		} 
		else if(driver.getTitle().contains("Administator Login"))
		{
			Assert.assertTrue(true);
		}
	}

	@When("supplier open url {string}")
	public void supplier_open_url(String supplierurl) throws InterruptedException {
		driver.get(supplierurl);
		   Thread.sleep(3000);
		   driver.manage().window().maximize();
	}

	@When("supplier enters Email as {string} and password as {string}")
	public void supplier_enters_email_as_and_password_as(String email, String Password) throws InterruptedException {
		Thread.sleep(3000);
		login.adminEmail(email);
		Thread.sleep(1000);
		login.adminPassword(Password);
		Thread.sleep(3000);
	}

	@Then("supplier Page title should contain {string}")
	public void supplier_page_title_should_contain(String title) throws InterruptedException {
		Thread.sleep(3000);
		
		if(driver.getTitle().contains(title)) {
			driver.close();
			Assert.assertTrue(true);
		} 
		else if(driver.getTitle().contains("Supplier Login"))
		{
			Assert.assertTrue(true);
		}
	}

	@Then("Page url should contain {string}")
	public void page_url_should_contain(String title) throws InterruptedException {
		Thread.sleep(3000);
		if(driver.getCurrentUrl().contains(title)){
	    	Assert.assertTrue(true);}
		else {
			Assert.assertTrue(false);
		}
		Thread.sleep(3000);
	}

	

	@When("user click on My Booking link")
	public void user_click_on_my_booking_link() throws InterruptedException {
		Thread.sleep(3000);
		customer.clickMyBooking();
		Thread.sleep(3000);
	}

	@Then("page for booking url should contain {string}")
	public void page_for_booking_url_should_contain(String title) throws InterruptedException {
		Thread.sleep(3000);
		if(driver.getCurrentUrl().contains(title)){
	    	Assert.assertTrue(true);}
		else {
			Assert.assertTrue(false);
		}
	}

	@When("user can click on view voucher button")
	public void user_can_click_on_view_voucher_button() throws InterruptedException {
		Thread.sleep(3000);
		customer.Window();
		customer.clickVoucher();
	}

	@Then("button for voucher is clickable")
	public void button_for_voucher_is_clickable() throws InterruptedException {
//		Thread.sleep(3000);
//		JavascriptExecutor ex= (JavascriptExecutor)driver;
//		ex.executeScript("window.scrollBy(0,1000)");
//		Thread.sleep(3000);
//		boolean invoice = customer.downloadInvoice();
//		Assert.assertTrue(invoice);
		Thread.sleep(5000);
		boolean clickable = customer.buttoninvoice();
		Assert.assertTrue(clickable);
		Thread.sleep(3000);
	}

	@Then("user can navigate back to booking page")
	public void user_can_navigate_back_to_booking_page() throws InterruptedException {
		Thread.sleep(3000);
		driver.switchTo().window(customer.Window());
		Thread.sleep(3000);
	}

	@When("user click on Add_Funds link")
	public void user_click_on_add_funds_link() throws InterruptedException {
		Thread.sleep(3000);
		customer.clickAddFunds();
	}

	@Then("page for add_funds url should contain {string}")
	public void page_for_add_funds_url_should_contain(String add_funds) throws InterruptedException {
		Thread.sleep(3000);
		if(driver.getCurrentUrl().contains("add_funds")){
	    	Assert.assertTrue(true);}
		else {
			Assert.assertTrue(false);
		}
		Thread.sleep(3000);
	}

	@Then("user can click on radio button as pay with paypal")
	public void user_can_click_on_radio_button_as_pay_with_paypal() throws InterruptedException {
		Thread.sleep(3000);
		customer.clickPaywithPaypal();
	}

	@When("user click on paynow button")
	public void user_click_on_paynow_button() throws InterruptedException {
		Thread.sleep(3000);
		customer.clickPayNow();
	}

	@Then("page for paypal payment url should contain {string}")
	public void page_for_paypal_payment_url_should_contain(String paypal) throws InterruptedException {
		Thread.sleep(3000);
		if(driver.getCurrentUrl().contains("paypal")){
	    	Assert.assertTrue(true);}
		else {
			Assert.assertTrue(false);
		}
		Thread.sleep(3000);
	}

	@Then("user click on back to invoice button")
	public void user_click_on_back_to_invoice_button() throws InterruptedException {
		Thread.sleep(3000);
		customer.clickBacktoInvoice();
	}

	@When("user accept the alert message")
	public void user_accept_the_alert_message() throws InterruptedException {
		Thread.sleep(3000);
		customer.clickAlertYes();
	}

	@Then("navigate to add_funds page and url should contain {string}")
	public void navigate_to_add_funds_page_and_url_should_contain(String add_funds) throws InterruptedException {
		Thread.sleep(3000);
		if(driver.getCurrentUrl().contains("add_funds")){
	    	Assert.assertTrue(true);}
		else {
			Assert.assertTrue(false);
		}
		Thread.sleep(3000);
	}

	@When("user can click on My Profile button")
	public void user_can_click_on_my_profile_button() throws InterruptedException {
		Thread.sleep(3000);
		customer.clickMyProfile();
	}

	@Then("navigate to profile page")
	public void navigate_to_profile_page() throws InterruptedException {
		Thread.sleep(3000);
		if(driver.getCurrentUrl().contains("profile")){
	    	Assert.assertTrue(true);}
		else {
			Assert.assertTrue(false);
		}
		Thread.sleep(3000);
	}

	@Then("user can edit the Address as {string}")
	public void user_can_edit_the_address_as(String text) throws InterruptedException {
		Thread.sleep(3000);
		JavascriptExecutor ex= (JavascriptExecutor)driver;
		ex.executeScript("window.scrollBy(0,800)");
		customer.strAddress(text);
		ex.executeScript("window.scrollBy(0,800)");
		Thread.sleep(3000);
		customer.clickUpdate();
	}

	@Then("profile page url should contain {string}")
	public void profile_page_url_should_contain(String sucess) throws InterruptedException {
		Thread.sleep(3000);
		String currenturl=driver.getCurrentUrl();
		Assert.assertTrue(currenturl.contains(sucess));
	}

	@Then("user can click on Logout link")
	public void user_can_click_on_logout_link() throws InterruptedException {
		Thread.sleep(3000);
		customer.clickLogout();
	}

	@Then("page url can contain {string}")
	public void page_url_can_contain(String login) throws InterruptedException {
		Thread.sleep(3000);
		String currenturl=driver.getCurrentUrl();
		Assert.assertTrue(currenturl.contains(login));
	}
//	@When("user click on Links")
//	public void user_click_on_links() throws InterruptedException {
//		Thread.sleep(3000);
//		customer.clickMyBooking();
//		Thread.sleep(3000);
//		customer.clickAddFunds();
//		Thread.sleep(3000);
//		customer.clickMyProfile();
//		Thread.sleep(3000);
//		
//		agent.clickHotels();
//		Thread.sleep(4000);
//		agent.clickFlights();
//		Thread.sleep(3000);
//		agent.clickTours();
//		Thread.sleep(3000);
//		agent.clickVisa();
//		Thread.sleep(3000);
//		agent.clickBlog();
//		Thread.sleep(3000);
//		agent.clickOffers();
//		Thread.sleep(3000);
//		agent.clickHome();
//		Thread.sleep(3000);
//		agent.account();
//		Thread.sleep(3000);
//		agent.accountLogout();
//		Thread.sleep(3000);
//	}
	
//	@Then("link url should contain {string}")
//	public void link_url_should_contain(String Title) throws InterruptedException {
//		Thread.sleep(3000);
//		if(driver.getCurrentUrl().contains(Title)){
//	    	Assert.assertTrue(true);}
//		else {
//			Assert.assertTrue(false);
//		}
//		Thread.sleep(3000);
//	}
//	@When("user click on Links")
//	public void user_click_on_links() {
//	    // Write code here that turns the phrase above into concrete actions
//	    throw new io.cucumber.java.PendingException();
//	}

//	@Then("agent page url should contain {string}")
//	public void agent_page_url_should_contain(String title) throws InterruptedException {
//		Thread.sleep(3000);
//		if(driver.getCurrentUrl().contains(title)){
//	    	Assert.assertTrue(true);}
//		else {
//			Assert.assertTrue(false);
//		}
//		Thread.sleep(3000);
//	}
	
	@When("user click on Agent My booking Link")
	public void user_click_on_agent_my_booking_link() throws InterruptedException {
		Thread.sleep(3000);
		customer.clickMyBooking();
		Thread.sleep(3000);
	}

	@Then("agent page url should contain {string}")
	public void agent_page_url_should_contain(String title) throws InterruptedException {
		Thread.sleep(3000);
		if(driver.getCurrentUrl().contains(title)){
	    	Assert.assertTrue(true);}
		else {
			Assert.assertTrue(false);
		}
		Thread.sleep(3000);
	}

	@When("user click on Agent Add_funds Link")
	public void user_click_on_agent_add_funds_link() throws InterruptedException {
		Thread.sleep(3000);
		customer.clickAddFunds();
		Thread.sleep(3000);
	}

	@When("user click on My Profile Link")
	public void user_click_on_my_profile_link() throws InterruptedException {
		Thread.sleep(3000);
		customer.clickMyProfile();
		Thread.sleep(3000);
	}

	@Then("user click on Logout")
	public void user_click_on_logout() throws InterruptedException {
		Thread.sleep(3000);
		customer.clickLogout();
		Thread.sleep(3000);
	}

	@When("user click on Hotels Link")
	public void user_click_on_hotels_link() throws InterruptedException {
		Thread.sleep(1000);
		agent.clickHotels();
		Thread.sleep(1000);
		
	}

	@When("user click on Flights Link")
	public void user_click_on_flights_link() throws InterruptedException {
		Thread.sleep(3000);
		agent.clickFlights();
		Thread.sleep(3000);
		
	}

	@When("user click on Tours Link")
	public void user_click_on_tours_link() throws InterruptedException {
		Thread.sleep(3000);
		agent.clickTours();
		Thread.sleep(3000);
		
	}

	@Then("user click on Visa Link")
	public void user_click_on_visa_link() throws InterruptedException {
		Thread.sleep(3000);
		agent.clickVisa();
		Thread.sleep(3000);
		
	}

	@Then("user click on Blog Link")
	public void user_click_on_blog_link() throws InterruptedException {
		Thread.sleep(3000);
		agent.clickBlog();
		Thread.sleep(3000);
		
	}

	@Then("user click on Offers Link")
	public void user_click_on_offers_link() throws InterruptedException {
		Thread.sleep(3000);
		agent.clickOffers();
		Thread.sleep(3000);
		
	}

	@When("user click on Home Logo")
	public void user_click_on_home_logo() throws InterruptedException {
		Thread.sleep(3000);
		agent.clickHome();
		Thread.sleep(3000);
	}

	@Then("agent page title should contain {string}")
	public void agent_page_title_should_contain(String title) {
	String actual = driver.getTitle();
	Assert.assertEquals(title, actual);
	}
	
	@When("user can enter {string} on city name field")
	public void user_can_enter_on_city_name_field(String cityname) throws InterruptedException {
		Thread.sleep(2000);
		agent.clickCityName();
		Thread.sleep(2000);
		agent.strCityName(cityname);
		Thread.sleep(2000);
		agent.selectOption();
//		agent.clickCity();
//		Thread.sleep(3000);
//		agent.strCity(city);
//		Thread.sleep(3000);
//		agent.searchByCity();
	}

	

	@When("click on search button")
	public void click_on_search_button() throws InterruptedException {
		Thread.sleep(3000);
		agent.clickSearch();
		Thread.sleep(3000);
	}
	
	@When("user click on USD dropdown menu")
	public void user_click_on_usd_dropdown_menu() throws InterruptedException {
		Thread.sleep(3000);
		agent.clickCurrency();
	    
	}

	@When("user can select INR from dropdowm menu")
	public void user_can_select_inr_from_dropdowm_menu() throws InterruptedException {
		Thread.sleep(3000);
	    agent.updateCurrency();
	}
// Admin Page
	
	@When("admin enters Email as {string} and password as {string}")
	public void admin_enters_email_as_and_password_as(String email, String password) throws InterruptedException {
		Thread.sleep(2000);
		login.adminEmail(email);
		Thread.sleep(1000);
		login.adminPassword(password);
		Thread.sleep(1000);
	}

	@When("admin click Login button")
	public void admin_click_login_button() throws InterruptedException {
		Thread.sleep(3000);
		login.clickAdminLogin();
		Thread.sleep(3000);
	}

	@Then("Page title should be {string}")
	public void page_title_should_be(String title) throws InterruptedException {
		Thread.sleep(5000);
		String actual = driver.getTitle();
		Assert.assertEquals(title, actual);
	}

	@When("admin click on Bookings Link")
	public void admin_click_on_bookings_link() throws InterruptedException {
		Thread.sleep(3000);
	    admin.clickAdminBooking();
	}

	@When("user click on invoice button")
	public void user_click_on_invoice_button() throws InterruptedException {
		Thread.sleep(3000);
		String oldTab = driver.getWindowHandle();
		admin.clickAdminInvoice();
		ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
	    newTab.remove(oldTab);
	    driver.switchTo().window(newTab.get(0));
		Thread.sleep(3000);
	}
	
	@Then("user can check the booking status is paid or not")
	public void user_can_check_the_booking_status_is_paid_or_not() throws InterruptedException {
		Thread.sleep(3000);
		boolean status =admin.getStatus();
		if(status=true) {
			System.out.println("The payment is sucessful " + status);
		}
		else {
			System.out.println("The payment is unsucessful "+ status);
		}
	}

	@When("user click on delete button and invoice should be deleted after accepting alert message")
	public void user_click_on_delete_button_and_invoice_should_be_deleted_after_accepting_alert_message() throws Exception {
		Thread.sleep(3000);
		admin.deleteAdminInvoice();
	}
	
	@When("admin click on Pending booking Link on dashboard")
	public void admin_click_on_pending_booking_link_on_dashboard() throws InterruptedException {
		Thread.sleep(3000);
		admin.clickPending();
	}

	@Then("the count before change the status is verified by admin")
	public void the_count_before_change_the_status_is_verified_by_admin() throws InterruptedException {
		Thread.sleep(3000);
		 String oldnum = admin.numPending();
		 String oldnumc = admin.numConfirm();
		 System.out.println("The old pending count is: "+ oldnum);
		 System.out.println("The old confirmed count is: "+ oldnumc);
	}

	@Then("admin click on booking status pending dropdown and change to confirmed")
	public void admin_click_on_booking_status_pending_dropdown_and_change_to_confirmed() throws InterruptedException {
		Thread.sleep(3000);
		admin.selectPending();
		Thread.sleep(2000);
		admin.selectConform();
	}

	@Then("the count after change the status in dashbord is verified by admin")
	public void the_count_after_change_the_status_in_dashbord_is_verified_by_admin() throws InterruptedException {
		Thread.sleep(3000);
		 String newnump = admin.numPending();
		 String newnumc = admin.numConfirm();
		 System.out.println("The new pending count is: "+ newnump);
		 System.out.println("The new confirmed count is: "+ newnumc);
	}
	
	@When("admin click on Website link")
	public void admin_click_on_website_link() throws InterruptedException {
		Thread.sleep(3000);
		String oldTab = driver.getWindowHandle();
		admin.selectWbsite();
		Thread.sleep(3000);
		ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
	    newTab.remove(oldTab);
	    driver.switchTo().window(newTab.get(0));
	    Thread.sleep(3000);
	}
	
//	@Then("close browser")
//	public void close_browser() throws InterruptedException {
//		Thread.sleep(3000);
//		driver.quit();
//	}
@After
public void closeBrowser() {
	driver.quit();
}
}
